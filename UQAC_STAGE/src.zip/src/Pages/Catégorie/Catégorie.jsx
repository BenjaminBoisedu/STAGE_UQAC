import React from "react";

export default function Catégorie() {
  return <div>Catégorie</div>;
}
